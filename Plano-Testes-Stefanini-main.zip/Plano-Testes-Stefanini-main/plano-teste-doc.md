# Plano de Testes de Software
Requisitos para realização dos testes de software são:

●	Site publicado na Internet

●	Navegador da Internet – Chrome e Edge

Os testes funcionais a serem realizados no aplicativo são descritos a seguir.

![Caso de teste](img/CT01.PNG)

![Caso de teste](img/CT02.PNG)

![Caso de teste](img/CT03.PNG)

![Caso de teste](img/CT04.PNG)

![Caso de teste](img/CT05.PNG)

![Caso de teste](img/CT06.PNG)

![Caso de teste](img/CT07.PNG)

![Caso de teste](img/CT08.PNG)

![Caso de teste](img/CT09.PNG)

![Caso de teste](img/CT10.PNG)
