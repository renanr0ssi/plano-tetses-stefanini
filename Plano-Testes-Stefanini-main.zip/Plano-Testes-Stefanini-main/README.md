# Desafio Stefanini
Desenvolvimento documental do plano de teste para o desafio da aplicação sugerida pela Stefanini.

Devido a fatores como tempo, disponibilidade e conhecimento nesse momento não me senti segura em desenvolver a aplicação em si, porém vi a possibilidade em ser analisada / avaliada  quanto a questão de testes da aplicação. Optei por essa forma de demonstrar meu pouco conhecimento na área descrita, através da documentação.
